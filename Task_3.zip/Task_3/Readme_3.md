# Basic Rule-Based Chatbot

## Project Description
This project is a simple rule-based chatbot developed in Python. It interacts with users by responding to predefined inputs such as greetings, questions about its well-being, and exit commands.

The chatbot demonstrates fundamental programming concepts, including functions, loops, conditional statements, and input/output operations.


## Objective
To build a basic chatbot that:
- Accepts user input continuously.
- Responds with predefined messages.
- Terminates the conversation when the user types `bye`.


## Technologies Used
- Python 3.x


## Concepts Used
- Functions
- `while` loops
- `if-elif-else` conditional statements
- User input (`input()`)
- Console output (`print()`)