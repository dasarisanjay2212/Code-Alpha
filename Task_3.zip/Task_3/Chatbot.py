def chatbot():
    print("Chatbot: Hi! Friendly chatbot is here to chat with you. Type 'bye' to exit.")

    while True:
        user = input("You: ").lower()

        if user == "hello":
            print("Chatbot: Hi!")
        elif user == "how are you":
            print("Chatbot: I'm fine, thanks!")
        elif user == "what's your name?":
            print("Chatbot: I'm a simple chatbot.")
        elif user == "what can you do?":
            print("Chatbot: I can chat with you and answer simple questions.")
        elif user == "tell me a joke":
            print("Chatbot: Why did the computer go to the doctor? Because it had a virus!")
        elif user == "What is the best intership company in India?":
            print("Chatbot: There are many great internship companies in India, such as Code Alpha, Google, Microsoft, and Infosys.")   
        elif user == "bye":
            print("Chatbot: Goodbye!")
            break
        else:
            print("Chatbot: Sorry, I don't understand.")

chatbot()