# Stock Portfolio Tracker

## Overview

This Python program calculates the total investment value of a stock portfolio using predefined stock prices. The user enters stock symbols and quantities, and the program computes the total amount invested. The result is also saved to a text file named `portfolio.txt`.

## Features

* Uses hardcoded stock prices.
* Accepts multiple stock entries from the user.
* Calculates the total investment value.
* Handles unavailable stock symbols.
* Saves the final investment value to a text file.

## How the Code Works

### 1. Store Stock Prices

A dictionary is used to store stock symbols and their corresponding prices.

```python
stock_prices = {
    "AAPL": 180,
    "TSLA": 250,
    "GOOGL": 140,
    "MSFT": 320
}
```

This allows quick access to stock prices using the stock symbol as the key.

### 2. Initialize Total Investment

The variable `total_investment` is initialized to zero.

```python
total_investment = 0
```

It keeps track of the total amount invested in all stocks.

### 3. Get Number of Stocks

The user enters how many different stocks they want to include in the portfolio.

```python
n = int(input("Enter the number of stocks: "))
```

### 4. Input Stock Details

A loop runs `n` times to collect:

* Stock symbol
* Quantity of shares

```python
for i in range(n):
    stock_name = input(...).upper()
    quantity = int(input(...))
```

The `.upper()` function ensures that the stock symbol matches the dictionary keys.

### 5. Calculate Investment Value

The program checks whether the stock exists in the dictionary.

```python
if stock_name in stock_prices:
```

If it exists, the investment value is calculated as:

```python
investment = stock_prices[stock_name] * quantity
```

The value is then added to `total_investment`.

### 6. Handle Invalid Stocks

If the user enters a stock symbol that is not available, an error message is displayed.

```python
else:
    print(f"{stock_name} is not available in the stock list.")
```

### 7. Display Total Investment

After processing all stocks, the total investment value is printed.

```python
print("\nTotal Investment Value: $", total_investment)
```

### 8. Save Result to a File

The total investment value is stored in a text file called `portfolio.txt`.

```python
with open("portfolio.txt", "w") as file:
    file.write(f"Total Investment Value: ${total_investment}")
```

## Example Execution

```text
Enter the number of stocks: 2

Enter stock symbol (AAPL, TSLA, GOOGL, MSFT): AAPL
Enter quantity: 3

Enter stock symbol (AAPL, TSLA, GOOGL, MSFT): TSLA
Enter quantity: 2

Total Investment Value: $1040
Result saved to portfolio.txt
```

## Time Complexity

* Dictionary lookup: O(1)
* Processing `n` stocks: O(n)

Overall Time Complexity: **O(n)**

## Output File

The program generates a file named:

```text
portfolio.txt
```

Example content:

```text
Total Investment Value: $1040
```

## Requirements

* Python 3.x
* No external libraries required
