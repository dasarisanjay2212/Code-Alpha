# Hangman Game in Python

## Description

This is a simple command-line Hangman game written in Python. The program randomly selects a word from a predefined list, and the player must guess the word one letter at a time within a limited number of attempts.

---

## Features

* Random word selection
* Input validation
* Tracks guessed letters
* Prevents duplicate guesses
* Displays remaining attempts
* Win and lose conditions

---

## Requirements

* Python 3.x

No additional libraries are required because the program only uses Python's built-in `random` module.

---

## How the Code Works

### 1. Import the Random Module

```python
import random
```

The `random` module is used to randomly select a word from the list.

---

### 2. Create a List of Words

```python
words = ["python", "computer", "program", "hangman", "coding"]
```

These are the possible words that the player may have to guess.

---

### 3. Select a Random Word

```python
word = random.choice(words)
```

The `random.choice()` function picks one word randomly from the list.

---

### 4. Initialize Variables

```python
guessed_letters = []
attempts = 6
```

* `guessed_letters` stores all letters guessed by the player.
* `attempts` keeps track of the remaining incorrect guesses.

---

### 5. Display Welcome Message

```python
print("Welcome to Hangman!")
```

This message is shown when the game starts.

---

### 6. Start the Game Loop

```python
while attempts > 0:
```

The game continues until:

* The player guesses the word correctly, or
* The player runs out of attempts.

---

### 7. Display the Current Word Progress

```python
display_word = ""

for letter in word:
    if letter in guessed_letters:
        display_word += letter + " "
    else:
        display_word += "_ "
```

* Correctly guessed letters are displayed.
* Unguessed letters are shown as underscores (`_`).

Example:

```text
Word: p _ t _ _ n
```

---

### 8. Show Remaining Attempts

```python
print("Attempts left:", attempts)
```

This tells the player how many incorrect guesses are still available.

---

### 9. Check for a Win

```python
if "_" not in display_word:
    print("Congratulations! You guessed the word:", word)
    break
```

If no underscores remain, the player has guessed the entire word and wins the game.

---

### 10. Take User Input

```python
guess = input("Enter a letter: ").lower()
```

The player enters a letter, which is converted to lowercase for consistency.

---

### 11. Validate the Input

```python
if len(guess) != 1 or not guess.isalpha():
    print("Please enter a single alphabet letter.")
    continue
```

The program ensures that:

* Only one character is entered.
* The character is a letter.

---

### 12. Prevent Duplicate Guesses

```python
if guess in guessed_letters:
    print("You already guessed that letter.")
    continue
```

If the player has already guessed the letter, the program asks for another input.

---

### 13. Store the Guess

```python
guessed_letters.append(guess)
```

The guessed letter is added to the list of previous guesses.

---

### 14. Check Whether the Guess Is Correct

```python
if guess in word:
    print("Correct guess!")
else:
    print("Wrong guess!")
    attempts -= 1
```

* Correct guesses reveal letters in the word.
* Incorrect guesses reduce the number of remaining attempts.

---

### 15. Game Over Condition

```python
if attempts == 0:
    print("\nGame Over! The word was:", word)
```

If all attempts are used, the player loses, and the correct word is displayed.

---

## Sample Output

```text
Welcome to Hangman!

Word: _ _ _ _ _ _
Attempts left: 6
Enter a letter: p
Correct guess!

Word: p _ _ _ _ _
Attempts left: 6
Enter a letter: x
Wrong guess!

Attempts left: 5

Congratulations! You guessed the word: python


## Future Improvements

* Add difficulty levels
* Read words from a text file
* Display ASCII Hangman graphics
* Allow players to guess the entire word
* Add score tracking and multiple rounds


## Author

Simple Python Hangman Game Project
